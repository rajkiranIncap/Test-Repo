({
	doInit : function(component, event, helper) {
        var today = new Date();
        component.set('v.currentDate', today);
        const options=[{'value':1,'label':'Jaipur'},
                       {'value':2,'label':'Pune'},
                       {'value':3,'label':'Hyderabad'},
                       {'value':4,'label':'Banglore'},
                       {'value':5,'label':'Gurgaon'},
                       {'value':6,'label':'Mumbai'},
                       {'value':7,'label':'Chennai'},
                       {'value':8,'label':'Noida'},
                       {'value':9,'label':'Delhi'},
                      {'value':10,'label':'Delhi'},
                      {'value':11,'label':'Delhi'},
                      {'value':12,'label':'Delhi'},{'value':13,'label':'Delhi'},
                      {'value':14,'label':'Delhi'},
                      {'value':15,'label':'Delhi'},
                      {'value':16,'label':'Delhi'},
                      {'value':17,'label':'Delhi'},
                      {'value':18,'label':'Delhi'},
                      {'value':19,'label':'Delhi'},
                      {'value':20,'label':'Delhi'},
                      {'value':21,'label':'Delhi'},
                      {'value':22,'label':'Delhi'},];
                       
        
	}
})