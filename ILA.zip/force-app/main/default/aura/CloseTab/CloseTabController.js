({
	closeFocusedTabAndOpenNewTab : function(component, event, helper) {
        window.self.close();


   }
})