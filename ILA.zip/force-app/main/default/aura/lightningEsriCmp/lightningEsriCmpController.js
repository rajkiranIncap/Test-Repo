({
    myAction : function(component, event, helper) {
        setTimeout(function(){      
            var map;
            require(["esri/map", "dojo/domReady!"], function(Map) {
                map = new Map("mapDiv", {
                    center: [-56.049, 38.485],
                    zoom: 3,
                    basemap: "streets"
                });
            });
        }, 5000);
    }
})