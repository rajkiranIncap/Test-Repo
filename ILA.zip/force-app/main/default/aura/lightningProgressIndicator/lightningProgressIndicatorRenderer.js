({
    /**
     * Modified Since:  03/06/2019
     * Author: Incapsulate
     * 
    */
	// Your renderer method overrides go here
	 afterRender: function (component, helper) {
        this.superAfterRender();
        /*var divd = component.find("indicatordiv");
         $A.util.addClass(divd,"disable-pointerevent")*/
        // interact with the DOM here
    }
})