declare module "@salesforce/resourceUrl/IncapsulateLogo" {
    var IncapsulateLogo: string;
    export default IncapsulateLogo;
}
declare module "@salesforce/resourceUrl/SiteSamples" {
    var SiteSamples: string;
    export default SiteSamples;
}
declare module "@salesforce/resourceUrl/claimlogo" {
    var claimlogo: string;
    export default claimlogo;
}
declare module "@salesforce/resourceUrl/esri" {
    var esri: string;
    export default esri;
}
declare module "@salesforce/resourceUrl/jQuery_LookupCmp" {
    var jQuery_LookupCmp: string;
    export default jQuery_LookupCmp;
}
declare module "@salesforce/resourceUrl/leaflet" {
    var leaflet: string;
    export default leaflet;
}
declare module "@salesforce/resourceUrl/sldsicon" {
    var sldsicon: string;
    export default sldsicon;
}
declare module "@salesforce/resourceUrl/svgclose" {
    var svgclose: string;
    export default svgclose;
}
