declare module "@salesforce/apex/DynamicGenericReadOnlyController.getDynamicResponsne" {
  export default function getDynamicResponsne(param: {grr: any}): Promise<any>;
}
