declare module "@salesforce/apex/PartnerClaim.getClaims" {
  export default function getClaims(): Promise<any>;
}
