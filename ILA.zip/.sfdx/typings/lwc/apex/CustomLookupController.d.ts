declare module "@salesforce/apex/CustomLookupController.searchDB" {
  export default function searchDB(param: {objectName: any, fld_API_Text: any, fld_API_Val: any, lim: any, fld_API_Search: any, searchText: any}): Promise<any>;
}
