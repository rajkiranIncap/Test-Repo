declare module "@salesforce/apex/DocuSignUtil.updateSignedCase" {
  export default function updateSignedCase(param: {recordId: any}): Promise<any>;
}
