declare module "@salesforce/apex/DynamicControllerILALite.getComponentsByGroupName" {
  export default function getComponentsByGroupName(param: {groupName: any}): Promise<any>;
}
declare module "@salesforce/apex/DynamicControllerILALite.getRecords" {
  export default function getRecords(param: {objectType: any, recordTypeId: any, parentId: any, parentField: any, fields: any}): Promise<any>;
}
declare module "@salesforce/apex/DynamicControllerILALite.saveRecords" {
  export default function saveRecords(param: {savedRecords: any, deletedRecords: any}): Promise<any>;
}
