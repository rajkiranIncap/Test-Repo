declare module "@salesforce/apex/DatatableGridController.getAccounts" {
  export default function getAccounts(): Promise<any>;
}
declare module "@salesforce/apex/DatatableGridController.updateAccounts" {
  export default function updateAccounts(param: {editedAccountList: any}): Promise<any>;
}
