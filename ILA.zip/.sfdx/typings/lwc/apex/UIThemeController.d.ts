declare module "@salesforce/apex/UIThemeController.getUIThemeDescription" {
  export default function getUIThemeDescription(): Promise<any>;
}
