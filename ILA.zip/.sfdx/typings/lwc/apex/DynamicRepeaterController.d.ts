declare module "@salesforce/apex/DynamicRepeaterController.getComponentsByGroupName" {
  export default function getComponentsByGroupName(param: {groupName: any}): Promise<any>;
}
declare module "@salesforce/apex/DynamicRepeaterController.getRecords" {
  export default function getRecords(param: {objectType: any, recordTypeId: any, parentId: any, parentField: any, fields: any}): Promise<any>;
}
