declare module "@salesforce/apex/FormTableController.getComponentsByGroupNameNew" {
  export default function getComponentsByGroupNameNew(param: {groupName: any}): Promise<any>;
}
