declare module "@salesforce/apex/FileRelatedList.getRelatedFiles" {
  export default function getRelatedFiles(param: {entityIds: any}): Promise<any>;
}
declare module "@salesforce/apex/FileRelatedList.deleteDocument" {
  export default function deleteDocument(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/FileRelatedList.saveDocumentAdditionalDetail" {
  export default function saveDocumentAdditionalDetail(param: {recordId: any, jsonString: any}): Promise<any>;
}
declare module "@salesforce/apex/FileRelatedList.getBaseUrl" {
  export default function getBaseUrl(): Promise<any>;
}
