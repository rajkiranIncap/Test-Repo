declare module "@salesforce/apex/PopulatePicklist.getPicklistValues" {
  export default function getPicklistValues(param: {obj: any, fld: any, recordTypeDeveloperName: any}): Promise<any>;
}
declare module "@salesforce/apex/PopulatePicklist.getPicklistFromSobjectValues" {
  export default function getPicklistFromSobjectValues(param: {obj: any, fld: any, recordTypeDeveloperName: any}): Promise<any>;
}
