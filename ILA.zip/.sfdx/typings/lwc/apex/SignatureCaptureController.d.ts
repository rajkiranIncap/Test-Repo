declare module "@salesforce/apex/SignatureCaptureController.saveSignature" {
  export default function saveSignature(param: {signatureBody: any}): Promise<any>;
}
