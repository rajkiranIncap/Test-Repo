declare module "@salesforce/apex/FormElementInfoService.getComponentsByGroupNameCustomMetadata" {
  export default function getComponentsByGroupNameCustomMetadata(param: {groupName: any}): Promise<any>;
}
