declare module "@salesforce/apex/BaseIC_FileRelatedList.getRelatedFiles" {
  export default function getRelatedFiles(param: {entityIds: any}): Promise<any>;
}
declare module "@salesforce/apex/BaseIC_FileRelatedList.deleteDocument" {
  export default function deleteDocument(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/BaseIC_FileRelatedList.saveDocumentAdditionalDetail" {
  export default function saveDocumentAdditionalDetail(param: {recordId: any, jsonString: any}): Promise<any>;
}
declare module "@salesforce/apex/BaseIC_FileRelatedList.getBaseUrl" {
  export default function getBaseUrl(): Promise<any>;
}
