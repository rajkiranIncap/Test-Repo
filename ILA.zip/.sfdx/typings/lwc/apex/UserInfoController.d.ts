declare module "@salesforce/apex/UserInfoController.getUserInfo" {
  export default function getUserInfo(): Promise<any>;
}
