declare module "@salesforce/apex/DependentPicklistController.getSelectOptions" {
  export default function getSelectOptions(param: {objectName: any, fld: any}): Promise<any>;
}
declare module "@salesforce/apex/DependentPicklistController.getDependentMapFromSobjectOrDependentpicklist" {
  export default function getDependentMapFromSobjectOrDependentpicklist(param: {isDepedentBasedOnSobjects: any, objectName: any, contrfieldApiName: any, depfieldApiName: any, controllingSobjectAPI: any, dependentSobjectAPI: any}): Promise<any>;
}
declare module "@salesforce/apex/DependentPicklistController.getDependentMap" {
  export default function getDependentMap(param: {objectName: any, contrfieldApiName: any, depfieldApiName: any}): Promise<any>;
}
