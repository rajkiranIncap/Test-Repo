declare module "@salesforce/apex/CustomerPolicyController.getPolicies" {
  export default function getPolicies(): Promise<any>;
}
declare module "@salesforce/apex/CustomerPolicyController.getPolicyType" {
  export default function getPolicyType(param: {policyId: any}): Promise<any>;
}
