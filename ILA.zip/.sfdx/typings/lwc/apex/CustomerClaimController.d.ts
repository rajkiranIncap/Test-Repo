declare module "@salesforce/apex/CustomerClaimController.getClaims" {
  export default function getClaims(): Promise<any>;
}
