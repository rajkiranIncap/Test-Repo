declare module "@salesforce/apex/RepeaterController.getComponentsByGroupNameCustomMetadata" {
  export default function getComponentsByGroupNameCustomMetadata(param: {groupName: any}): Promise<any>;
}
declare module "@salesforce/apex/RepeaterController.getComponentsByGroupName" {
  export default function getComponentsByGroupName(param: {groupName: any}): Promise<any>;
}
declare module "@salesforce/apex/RepeaterController.deleteRecord" {
  export default function deleteRecord(param: {recordId: any, ObjectType: any}): Promise<any>;
}
