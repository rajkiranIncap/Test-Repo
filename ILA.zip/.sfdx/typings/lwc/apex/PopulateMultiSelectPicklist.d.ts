declare module "@salesforce/apex/PopulateMultiSelectPicklist.getPicklistValues" {
  export default function getPicklistValues(param: {obj: any, fld: any}): Promise<any>;
}
