declare module "@salesforce/apex/DynamicTableController.getColumnMetadata" {
  export default function getColumnMetadata(param: {sobject_name: any, field_names: any, field_labels: any, sortable_field_names: any, reference_fields: any, override_field_type: any}): Promise<any>;
}
declare module "@salesforce/apex/DynamicTableController.getTotalRecords" {
  export default function getTotalRecords(param: {sobject_name: any, match_criteria: any}): Promise<any>;
}
declare module "@salesforce/apex/DynamicTableController.getRecords" {
  export default function getRecords(param: {sobject_name: any, field_names: any, match_criteria: any, sort_by_field: any, sort_order: any, MAX_QUERY_RECORDS: any}): Promise<any>;
}
